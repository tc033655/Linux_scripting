#!/bin/bash
### Author : Tridibesh Chakraborty
### Purpose : Prepare patching report
### This will work on Redhat/Centos & Suse
### Date : 5th September 2018
### Version : 0.1 (BETA)

SCRIPT=$0
INVENTORY=$1
USER=$2

TOTAL_ARG=$#

if [ "$TOTAL_ARG" -lt 2 ]; then
	echo "Please execute the script as below :-
	#./patching_dashboard.sh INVENTORY_FILE REMOTE_USER "
	exit 1
fi

SERVER_COUNT=`wc -l $INVENTORY | awk '{print $1}'`
TEMP_DIR=/tmp/patching_dashboard
CURRENT_EPOCH=`date +%s`
FINAL_OUT=$TEMP_DIR/final_report_`date "+%Y-%m-%d-%H_%M_%S"`.html

if [ -d $TEMP_DIR ]; then
	OUTPUT=$TEMP_DIR/patching_details.out
else
	mkdir $TEMP_DIR
	OUTPUT=$TEMP_DIR/patching_details.out
fi

for HOST in `cat $INVENTORY | awk '{print $1}'`
do
	mkdir $TEMP_DIR/$HOST.temp/
	scp $USER@$HOST:/var/log/os_upgrade.log $TEMP_DIR/$HOST.temp/
	#scp $USER@$HOST:/etc/os-release $TEMP_DIR/$HOST.temp/
	OS_TYPE=`awk '{print $1}' $TEMP_DIR/$HOST.temp/os_upgrade.log|tail -1`
	LAST_PATCHED_EPOCH=`awk '{print $12}' $TEMP_DIR/$HOST.temp/os_upgrade.log | cut -d ")" -f 1|tail -1`
	LAST_PATCHED_DATE=`awk '{print $9,$10}' $TEMP_DIR/$HOST.temp/os_upgrade.log | tail -1`
	SEC_DIFF=`echo $[ CURRENT_EPOCH - LAST_PATCHED_EPOCH ]`		
	DAY_DIFF=`echo $[ SEC_DIFF/86400 ]`
	if [ $DAY_DIFF -gt 30 ]; then
		echo "$HOST $OS_TYPE NOT_PATCHED $LAST_PATCHED_DATE" >>$OUTPUT	
	else
		echo "$HOST $OS_TYPE PATCHED $LAST_PATCHED_DATE" >>$OUTPUT
	fi
done

PATCHED=`grep -w -c PATCHED $OUTPUT`
NOT_PATCHED=`grep -w -c NOT_PATCHED $OUTPUT`
SUSE=`grep -w -c SLES $OUTPUT`
REDHAT=`grep -w -c RedHat $OUTPUT`
CENTOS=`grep -w -c CentOS $OUTPUT`
REDHAT_PATCHED=`grep -w RedHat $OUTPUT | grep -w -c PATCHED`
REDHAT_NOT_PATCHED=`grep -w RedHat $OUTPUT | grep -w -c NOT_PATCHED`
SUSE_PATCHED=`grep -w SLES $OUTPUT | grep -w -c PATCHED`
SUSE_NOT_PATCHED=`grep -w SLES $OUTPUT | grep -w -c NOT_PATCHED`
CENTOS_PATCHED=`grep -w CentOS $OUTPUT| grep -w -c PATCHED`
CENTOS_NOT_PATCHED=`grep -w CentOS $OUTPUT| grep -w -c NOT_PATCHED`

printf  "
<html>
<body>
<header>
	<h1 align="center"> <font color="green"> Patching Dashboard - Linux (`date`) </font></h1>
	<h2 align="center"> <font color="blue"> OVERALL PATCHING STATUS </font> </h2>
</header>
" >$FINAL_OUT
echo '
<script type="text/javascript">
window.onload = function () {
        var chart = new CanvasJS.Chart("chartContainer",
        {
                theme: "theme4",
                title:{
                        text: "Linux Patching Dashboard - Overall"
                },
                data: [
                {       
                        type: "pie",
                        showInLegend: true,
                        toolTipContent: "{y} - Servers",
                        yValueFormatString: "",
                        legendText: "{indexLabel}", '>>$FINAL_OUT
                  echo "dataPoints: [
                                {  y: "$PATCHED", indexLabel: \"Completed\" },
                                {  y: "$NOT_PATCHED", indexLabel: \"Pending\" }                                
                        ]
                }
                ]
        });
        chart.render();
}
</script> " >>$FINAL_OUT

echo '
<script type="text/javascript" src="/scripts/canvasjs.min.js"></script></head>

<div id="chartContainer" style="height: 300px; width: 100%;"></div>

' >>$FINAL_OUT

echo "

<table border="1" align="center">
	<tr align="center">
		<th> TOTAL SERVERS </th>
		<th bgcolor="#00FF00"> PATCHING COMPLETED </th>
		<th bgcolor="#FF0000"> PATCHING PENDING </th>
	</tr>

	<tr align="center">
		<td> $SERVER_COUNT </td>
		<td> $PATCHED </td>
		<td> $NOT_PATCHED </td>
	</tr>
</table>

<header>
        <h3 align="center"> Patching Status - Redhat </h1>
</header>

<table border="1" align="center">
        <tr align="center">
                <th> TOTAL SERVERS </th>
                <th bgcolor="#00FF00"> PATCHING COMPLETED </th>
                <th bgcolor="#FF0000"> PATCHING PENDING </th>
        </tr>

	<tr align="center">
		<td> $REDHAT </td>
		<td> $REDHAT_PATCHED </td>
		<td> $REDHAT_NOT_PATCHED </td>
	</tr>
</table>



<header>
        <h3 align="center"> Patching Status - CentOS </h1>
</header>


<table border="1" align="center">
        <tr align="center">
                <th> TOTAL SERVERS </th>
                <th bgcolor="#00FF00"> PATCHING COMPLETED </th>
                <th bgcolor="#FF0000"> PATCHING PENDING </th>
        </tr>

        <tr align="center">
                <td> $CENTOS </td>
                <td> $CENTOS_PATCHED </td>
                <td> $CENTOS_NOT_PATCHED </td>
        </tr>
</table>

<header>
        <h3 align="center"> Patching Status - SUSE </h1>
</header>


<table border="1" align="center">
        <tr align="center">
                <th> TOTAL SERVERS </th>
                <th bgcolor="#00FF00"> PATCHING COMPLETED </th>
                <th bgcolor="#FF0000"> PATCHING PENDING </th>
        </tr>

        <tr align="center">
                <td> $SUSE </td>
                <td> $SUSE_PATCHED </td>
                <td> $SUSE_NOT_PATCHED </td>
        </tr>
</table>

<header>
        <h2 align="center"> LAST PATCH DATE - LINUX </h1>
</header>

<table border="1" align="center">
	<tr align="center">
		<th> HOSTNAME </th>
		<th> IP ADDRESS </th>
		<th> OS TYPE </th>
		<th> ENVIRONMENT </th>
		<th> APPLICATION </th>
		<th> LAST PATCHED </th>
	</tr>


 " >>$FINAL_OUT


for SERVER in `awk '{print $1}' $OUTPUT` 
do
        OS=`grep -w $SERVER $OUTPUT|awk '{print $2}'`
        PATCH_TIME=`grep -w $SERVER $OUTPUT|awk '{print $4}'`
	IPADDR=`grep -w $SERVER $INVENTORY | awk '{print $2}'`
	ENVIRONMENT=`grep -w $SERVER $INVENTORY | awk '{print $3}'`
	APP=`grep -w $SERVER $INVENTORY | awk '{print $4}'`
	echo "
	<tr align="center">
		<td> $SERVER </td>
		<td> $IPADDR </td>
		<td> $OS </td>
		<td> $ENVIRONMENT </td>
		<td> $APP </td>
		<td> $PATCH_TIME </td>
	</tr>" >> $FINAL_OUT
done

echo "
</table>

</body>
</html>
" >> $FINAL_OUT

### Cleaning up temporary files 

rm -rf $OUTPUT $TEMP_DIR/*.temp

sudo cp $FINAL_OUT /var/www/html/index.html
