#!/bin/bash
# Author: Tridibesh Chakraborty
# Email: tridibesh.chakraborty@yahoo.com
# Version: 1.0 (BETA)
# Date: 24th July 2018

script_usage ()
{

echo "Wrong usage of the script. Please run the script as below:-
 /usr/local/bin/linux_dashboard.sh <list_of_servers> <os_details.out>

where the list_of_servers contain the list of servers and os_details.out is the output file where the script output will be saved
"
exit
}


script_name=linux_dashboard.sh
serverlist=$1
outputfile=$2
### Check the connectivity of the servers
printf "What is the username : "
read user
for host in `cat $serverlist`
do
echo "Checking connectiviy with the server : $host"
ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 "$user"@"$host" exit 1>/dev/null 2>/dev/null

if [ $? -eq 0 ]; then
	loginstatus=yes
	echo "Able to login : $host"
else
	loginstatus=no
	echo "Not able to login: $host"
fi

echo "Checking the OS details of server $host"
ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 "$user"@"$host" cat /etc/redhat-release >/tmp/$host_os-release 2>/dev/null

grep "Red Hat" /tmp/$host_os-release 1>/dev/null  2>/dev/null

if [ $? -eq 0 ]; then
	osfamily=redhat
	osversion=`awk '{print $7 }' /tmp/$host_os-release | head -1`
        osname=`cut -d "(" -f 2 /tmp/$host_os-release | cut -d ")" -f 1 | head -1`
	echo $host >>/tmp/redhat-hosts
	
	case $osname in
	Maipo)
		echo "$host : Redhat7"
		echo "$host" >>/tmp/redhat7-hosts
		;;
	Santiago)
		echo "$host : Redhat6"
		echo "$host" >>/tmp/redhat6-hosts
		;;
	Tikanga)
		echo "$host : Redhat5"
		echo "$host" >>/tmp/redhat5-hosts
		;;
	*)
		echo "$host : Other OS"
		echo "$host" >>/tmp/os-unknown
		;;
	esac
fi
done
