#!/bin/bash
### This script generates the OS upgrade log file /var/log/os_upgrade.log
echo "Checking the existing log file /var/log/os_upgrade.log"
if [ -e /var/log/os_upgrade.log ]; then
        echo "/var/log/os_upgrade.log already exists. Not creating new file"
else
        echo "Creating the log file /var/log/os_upgrade.log"
        touch /var/log/os_upgrade.log && chmod 777 /var/log/os_upgrade.log
fi

if [ -s /var/log/os_upgrade.log ]; then
        echo "Log file already contains entries.. So exiting..."
        exit
fi


echo "Collecting the Yum history"
yum history | grep "<" | egrep -v "Install|Erase" >/tmp/yum_history.log

HOST=`hostname -s`
IP=`hostname -i`

echo $IP | grep ":" 1>/dev/null 2>/dev/null
if [ $? -eq 0 ]; then
        IP=`echo $IP | awk '{print $2}'`
fi

if [ -z $IP ]; then
        IFACE=`ifconfig |head -1 | cut -d ":" -f 1`
        IP=`ifconfig $IFACE | grep -w inet | awk '{print $2}'|head -1`
fi


grep "Red Hat" /etc/redhat-release >/dev/null 2>/dev/null
if [ $? -eq 0 ]; then
        OS=RedHat
else
        OS=CentOS
fi

cut -d "|" -f 3 /tmp/yum_history.log > /tmp/yum_dates
sed -e 's/^/date --date="/' /tmp/yum_dates | gawk '{print $0"\" +%s"}' >/tmp/date_epoch_command
for DATE in `tac /tmp/yum_dates | awk '{print $1}'`
do
        TIME=`grep $DATE /tmp/yum_dates | awk '{print $2}' | tail -1`
        command=`grep "$DATE $TIME" /tmp/date_epoch_command|tail -1`
        EPOCH=`eval $command`
        echo "$OS OS upgrade completed successfully on $HOST ( $IP on $DATE $TIME:00 / $EPOCH )" >>/var/log/os_upgrade.log
done

