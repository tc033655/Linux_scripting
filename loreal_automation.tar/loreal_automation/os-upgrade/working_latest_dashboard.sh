#!/bin/bash
### Author : Tridibesh Chakraborty
### Purpose : Prepare patching report
### This will work on Redhat/Centos & Suse
### Date : 3rd December 2018 
### Version : 0.1 (BETA)

SCRIPT=$0
INVENTORY=$1
USER=$2

TOTAL_ARG=$#

if [ "$TOTAL_ARG" -lt 2 ]; then
	echo "Please execute the script as below :-
	#./patching_dashboard.sh INVENTORY_FILE REMOTE_USER "
	exit 1
fi

SERVER_COUNT=`wc -l $INVENTORY | awk '{print $1}'`
TEMP_DIR=/tmp/patching_dashboard
CURRENT_EPOCH=`date +%s`
FINAL_OUT=$TEMP_DIR/final_report_`date "+%Y-%m-%d-%H_%M_%S"`.csv

if [ -d $TEMP_DIR ]; then
	OUTPUT=$TEMP_DIR/patching_details.out
else
	mkdir $TEMP_DIR
	OUTPUT=$TEMP_DIR/patching_details.out
fi

for HOST in `cat $INVENTORY | awk '{print $1}'`
do
	mkdir $TEMP_DIR/$HOST.temp/
	scp patch_details.sh $USER@$HOST:/tmp/   
	ssh $USER@$HOST sudo /tmp/patch_details.sh
	scp $USER@$HOST:/var/log/os_upgrade.log $TEMP_DIR/$HOST.temp/
	scp $USER@$HOST:/tmp/patch_details/* $TEMP_DIR/$HOST.temp/
	#scp $USER@$HOST:/etc/os-release $TEMP_DIR/$HOST.temp/
	OS_TYPE=`awk '{print $1}' $TEMP_DIR/$HOST.temp/os_upgrade.log|tail -1`
	LAST_PATCHED_EPOCH=`awk '{print $12}' $TEMP_DIR/$HOST.temp/os_upgrade.log | cut -d ")" -f 1|tail -1`
	LAST_PATCHED_DATE=`awk '{print $9,$10}' $TEMP_DIR/$HOST.temp/os_upgrade.log | tail -1`
	SEC_DIFF=`echo $[ CURRENT_EPOCH - LAST_PATCHED_EPOCH ]`		
	DAY_DIFF=`echo $[ SEC_DIFF/86400 ]`
	if [ $DAY_DIFF -gt 30 ]; then
		echo "$HOST $OS_TYPE NOT_PATCHED $LAST_PATCHED_DATE" >>$OUTPUT	
	else
		echo "$HOST $OS_TYPE PATCHED $LAST_PATCHED_DATE" >>$OUTPUT
	fi
	echo "FULL PATCHING DETAILS - $HOST
=================================================" > $TEMP_DIR/$HOST-patch_details.csv
	cat $TEMP_DIR/$HOST.temp/os_upgrade.log >> $TEMP_DIR/$HOST-patch_details.csv
	echo "=================================================
SECURITY PATCH DETAILS - $HOST" >> $TEMP_DIR/$HOST-patch_details.csv
	cat $TEMP_DIR/$HOST.temp/patch_details.txt >> $TEMP_DIR/$HOST-patch_details.csv

echo "=================================================
PATCHING HISTORY DETAILS - $HOST
=================================================" >> $TEMP_DIR/$HOST-patch_details.csv
	cat $TEMP_DIR/$HOST.temp/patch_history.txt  >> $TEMP_DIR/$HOST-patch_details.csv

	
done

PATCHED=`grep -w -c PATCHED $OUTPUT`
NOT_PATCHED=`grep -w -c NOT_PATCHED $OUTPUT`
SUSE=`grep -w -c SLES $OUTPUT`
REDHAT=`grep -w -c RedHat $OUTPUT`
CENTOS=`grep -w -c CentOS $OUTPUT`
REDHAT_PATCHED=`grep -w RedHat $OUTPUT | grep -w -c PATCHED`
REDHAT_NOT_PATCHED=`grep -w RedHat $OUTPUT | grep -w -c NOT_PATCHED`
SUSE_PATCHED=`grep -w SLES $OUTPUT | grep -w -c PATCHED`
SUSE_NOT_PATCHED=`grep -w SLES $OUTPUT | grep -w -c NOT_PATCHED`
CENTOS_PATCHED=`grep -w CentOS $OUTPUT| grep -w -c PATCHED`
CENTOS_NOT_PATCHED=`grep -w CentOS $OUTPUT| grep -w -c NOT_PATCHED`

printf  "
Patching Dashboard - Linux 
(Report Generated on : `date`)
===================================================================
OVERALL PATCHING STATUS

" >$FINAL_OUT

TOTALSERVERS=`wc -l $INVENTORY| awk '{print $1}'`
echo "TOTAL SERVERS, PATCHING COMPLETED, PATCHING PENDING
$TOTALSERVERS,$PATCHED,$NOT_PATCHED

---

REDHAT - PATCHING STATUS

REDHAT SERVERS,PATCHING COMPLETED, PATCHING PENDING
$REDHAT,$REDHAT_PATCHED,$REDHAT_NOT_PATCHED

---

CENTOS - PATCHING STATUS

CENTOS SERVERS,PATCHING COMPLETED,PATCHING PENDING
$CENTOS,$CENTOS_PATCHED,$CENTOS_NOT_PATCHED

---

SUSE - PATCHING STATUS

SUSE SERVERS,PATCHING COMPLETED,PATCHING PENDING
$SUSE,$SUSE_PATCHED,$SUSE_NOT_PATCHED

---
" >> $FINAL_OUT

echo "LATEST PATCH DETAILS - LINUX

HOSTNAME,IP ADDRESS,OS TYPE,ENVIRONMENT,APPLICATION,LAST PATCHING DATE" >>$FINAL_OUT
for SERVER in `awk '{print $1}' $OUTPUT`
do
        OS=`grep -w $SERVER $OUTPUT|awk '{print $2}'`
        PATCH_TIME=`grep -w $SERVER $OUTPUT|awk '{print $4}'`
        IPADDR=`grep -w $SERVER $INVENTORY | awk '{print $2}'`
        ENVIRONMENT=`grep -w $SERVER $INVENTORY | awk '{print $3}'`
        APP=`grep -w $SERVER $INVENTORY | awk '{print $4}'`
        echo "
$SERVER,$IPADDR,$OS,$ENVIRONMENT,$APP,$PATCH_TIME " >>$FINAL_OUT
done

     
### Cleaning up temporary files 

rm -rf $OUTPUT $TEMP_DIR/*.temp 

