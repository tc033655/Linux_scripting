#!/bin/bash
## Author : Tridibesh Chakraborty
## Purpose : This script will collect the installed package details in the server
## Date : 5th December 2018
## Version : 0.1 (BETA)
## Email : T.E.Chakraborty@Accenture.com


OUTPUTDIR=/tmp/patch_details
PATCHDETAILS=$OUTPUTDIR/patch_details.txt

mkdir $TEMPDIR $OUTPUTDIR


echo "---" >$PATCHDETAILS

echo "Collecting the installed patches details..."

echo "List installed Security Advisory details
=========================================================="
echo "HOSTNAME,ADVISORY/CVE NO,SEVERITY,STATUS" >$PATCHDETAILS
zypper lp -a  --category security | grep -v "not needed" | grep "SUSE-SLE-SERVER" |awk '{print $3,$7"/"$5}' | sed -e 's/ /,/g' | sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Patched/' >> $PATCHDETAILS

echo "List installed CVE details
=========================================================="
zypper lp -a --cve --category security  | grep -v "not needed" | grep ^cve | grep "SUSE-SLE-SERVER" | awk '{print $3,$9"/"$7}' | sed -e 's/ /,/g' | sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Patched/' >>$PATCHDETAILS

echo "List available security Advisory updates
=========================================================="

zypper lp --category security | grep needed |  grep "SUSE-SLE-SERVER" |awk '{print $3,$7"/"$5}'|  sed -e 's/ /,/g' | sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Not Patched/' >>$PATCHDETAILS

echo "List available security CVE updates
=========================================================="
zypper lp --cve | grep ^cve | awk '{print $3,$9"/"$7}' |  sed -e 's/ /,/g' | sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Not Patched/' >>$PATCHDETAILS

chmod -R 777 $OUTPUTDIR
