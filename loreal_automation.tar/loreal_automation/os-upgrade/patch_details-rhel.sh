#!/bin/bash
## Author : Tridibesh Chakraborty
## Purpose : This script will collect the installed package details in the server
## Date : 4th December 2018
## Version : 0.1 (BETA)
## Email : T.E.Chakraborty@Accenture.com

TEMPDIR=/tmp/patch_details_tmp
OUTPUTDIR=/tmp/patch_details
PATCHDETAILS=$OUTPUTDIR/patch_details.txt

mkdir $TEMPDIR $OUTPUTDIR

#echo "Report Generation started on : `date`" > $PATCHDETAILS
#echo "Report Generation started on : `date`" > $OUTPUTDIR/patch_history.txt
echo "---" >$PATCHDETAILS

awk '{print $9}' /var/log/os_upgrade.log > $TEMPDIR/patching_dates
yum history > $TEMPDIR/yum_history

echo "Collecting the installed patches details..."

## List installed Security update
echo "List installed Security Advisory details
=========================================================="
echo "HOSTNAME,ADVISORY/CVE NO,SEVERITY,PACKAGE IMPACTED,STATUS" >$PATCHDETAILS
#yum updateinfo list security installed >> $PATCHDETAILS
yum updateinfo list security installed -q | awk '{print $1,$2,$3}' | sed 's/[[:space:]]/,/g'| sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Patched/' >>$PATCHDETAILS
echo "==========================================================
List Installed Security CVE details
=========================================================="
#echo "HOSTNAME,CVE NO,SEVERITY,PACKAGE IMPACTED,STATUS" >> $PATCHDETAILS 

## List installed security CVEs
yum updateinfo list cve installed -q |awk '{print $1,$2,$3}' | sed 's/[[:space:]]/,/g'| sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Patched/' >> $PATCHDETAILS 
echo "==========================================================
List available security Advisory updates
=========================================================="
#echo "ADVISORY NO,SEVERITY,PACKAGE IMPACTED" >> $PATCHDETAILS 
yum updateinfo list security -q | awk '{print $1,$2,$3}' | sed 's/[[:space:]]/,/g'| sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Not Patched/' >> $PATCHDETAILS

echo "==========================================================
List available security CVE updates
=========================================================="
#echo "CVE NO,SEVERITY,PACKAGE IMPACTED" >> $PATCHDETAILS
yum updateinfo list cve -q | awk '{print $1,$2,$3}' | sed 's/[[:space:]]/,/g'| sed -e "s/^/$HOSTNAME,/" | sed -e 's/$/,Not Patched/' >> $PATCHDETAILS

### Collecting installed packages as per dates
#for dates in `cat $TEMPDIR/patching_dates`
#do
#echo "Packages update history on : $dates
#==========================================================" >>$OUTPUTDIR/patch_history.txt
#TRNSID=`grep -w $dates $TEMPDIR/yum_history | awk '{print $1}'`
#yum history info $TRNSID >> $OUTPUTDIR/patch_history.txt
#echo "==========================================================" >>$OUTPUTDIR/patch_history.txt
#done

chmod -R 777 $OUTPUTDIR
rm -rf $TEMPDIR


