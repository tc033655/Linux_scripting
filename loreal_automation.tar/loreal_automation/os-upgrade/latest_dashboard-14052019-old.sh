#!/bin/bash
### Author : Tridibesh Chakraborty
### Purpose : Prepare patching report
### This will work on Redhat/Centos & Suse
### Date : 7th January 2019
### Version : 0.2 (Production)
### Change Log:
#### Adding the trap to perform cleanup incase there is an interrupt
#### Added the OS version (7th Jan 2019)

trap cleanup 1 2 3 6 9

cleanup ()
{
	echo "Trap signal received.. exiting from the script execution..."
	echo "Please wait for a moment while we perform the cleanup the temp files.."
	sleep 2
	rm -rf $FINAL_OUT $PATCH_FULL_DETAILS $OUTPUT $TEMP_DIR/*.temp
	echo "Cleanup activity completed... "
	exit 1 
}

SCRIPT=$0
INVENTORY=$1
USER=$2

TOTAL_ARG=$#

if [ "$TOTAL_ARG" -lt 2 ]; then
	echo "Please execute the script as below :-
	#./patching_dashboard.sh INVENTORY_FILE REMOTE_USER "
	exit 1
fi

#SERVER_COUNT=`wc -l $INVENTORY | awk '{print $1}'`
TEMP_DIR=/tmp/patching_dashboard
CURRENT_EPOCH=`date +%s`
DATE=`date "+%Y-%m-%d-%H_%M_%S"`
FINAL_OUT=$TEMP_DIR/overall_final_report_"$DATE".csv
PATCH_FULL_DETAILS=$TEMP_DIR/final_patch_report_"$DATE".csv
PATCH_HISTORY=$TEMP_DIR/full_patch_history_"$DATE".csv
echo "HOSTNAME,IP ADDRESS,OS,PATCHING DATE" >$PATCH_HISTORY
if [ -d $TEMP_DIR ]; then
	OUTPUT=$TEMP_DIR/patching_details.out
else
	mkdir $TEMP_DIR
	OUTPUT=$TEMP_DIR/patching_details.out
fi
echo "HOSTNAME,ADVISORY/CVE NO,SEVERITY,STATUS" >$PATCH_FULL_DETAILS

for HOST in `cat $INVENTORY | awk '{print $1}'`
do
	mkdir $TEMP_DIR/$HOST.temp/
	scp patch_details.sh $USER@$HOST:/tmp/   
	ssh $USER@$HOST sudo /tmp/patch_details.sh
	#scp $USER@$HOST:/var/log/os_upgrade.log $TEMP_DIR/$HOST.temp/
	#scp $USER@$HOST:/tmp/patch_details/patch_details.txt $TEMP_DIR/$HOST.temp/
	scp $USER@$HOST:'/etc/os-release /var/log/os_upgrade.log /tmp/patch_details/patch_details.txt' $TEMP_DIR/$HOST.temp/
	egrep -i "Patched|Available"  $TEMP_DIR/$HOST.temp/patch_details.txt >> $PATCH_FULL_DETAILS
	#scp $USER@$HOST:/etc/os-release $TEMP_DIR/$HOST.temp/
	OS_TYPE=`awk '{print $1}' $TEMP_DIR/$HOST.temp/os_upgrade.log|tail -1`
	OS_VER=`grep "VERSION_ID=" $TEMP_DIR/$HOST.temp/os-release | cut -d "\"" -f 2`
	#LAST_PATCHED_EPOCH=`awk '{print $12}' $TEMP_DIR/$HOST.temp/os_upgrade.log | cut -d ")" -f 1|tail -1`
	LAST_PATCHED_EPOCH=`awk '{print $14}' $TEMP_DIR/$HOST.temp/os_upgrade.log | tail -1`
	LAST_PATCHED_DATE=`awk '{print $11,$12}' $TEMP_DIR/$HOST.temp/os_upgrade.log | tail -1`
	SEC_DIFF=`echo $[ CURRENT_EPOCH - LAST_PATCHED_EPOCH ]`		
	DAY_DIFF=`echo $[ SEC_DIFF/86400 ]`
	awk '{print $7,",",$9,",",$1,",",$11}' $TEMP_DIR/$HOST.temp/os_upgrade.log >>$PATCH_HISTORY
	if [ $DAY_DIFF -gt 90 ]; then
		echo "$HOST $OS_TYPE NOT_PATCHED $LAST_PATCHED_DATE $OS_VER" >>$OUTPUT	
	else
		echo "$HOST $OS_TYPE PATCHED $LAST_PATCHED_DATE $OS_VER" >>$OUTPUT
	fi
	echo "FULL PATCHING DETAILS - $HOST
=================================================" > $TEMP_DIR/$HOST-patch_details.csv
	cat $TEMP_DIR/$HOST.temp/os_upgrade.log >> $TEMP_DIR/$HOST-patch_details.csv
	echo "=================================================
SECURITY PATCH DETAILS - $HOST" >> $TEMP_DIR/$HOST-patch_details.csv
	cat $TEMP_DIR/$HOST.temp/patch_details.txt >> $TEMP_DIR/$HOST-patch_details.csv


	
done


echo "REGION,HOSTNAME,IP ADDRESS,OS TYPE,OS VERSION,ENVIRONMENT,APPLICATION,LAST PATCHING DATE,STATUS" >>$FINAL_OUT
for SERVER in `awk '{print $1}' $OUTPUT`
do
        OS=`grep -w $SERVER $OUTPUT|awk '{print $2}'`
	OS_VERSION=`grep -w $SERVER $OUTPUT|awk '{print $NF}'`
        PATCH_TIME=`grep -w $SERVER $OUTPUT|awk '{print $4}'`
        IPADDR=`grep -w $SERVER $INVENTORY | awk '{print $2}'`
        ENVIRONMENT=`grep -w $SERVER $INVENTORY | awk '{print $3}'`
        APP=`grep -w $SERVER $INVENTORY | awk '{print $4}'`
	PSTATUS=`grep -w $SERVER $OUTPUT | awk '{print $3}'`
	REGION=`grep -w $SERVER $INVENTORY | awk '{print $5}'`
        echo "$REGION,$SERVER,$IPADDR,$OS,$OS_VERSION,$ENVIRONMENT,$APP,$PATCH_TIME,$PSTATUS " >>$FINAL_OUT
	
done

     
### Cleaning up temporary files 
#### Generating the Patching history file

rm -rf $OUTPUT $TEMP_DIR/*.temp 

chmod -R 777 $TEMP_DIR
